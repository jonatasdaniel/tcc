package br.furb.rma.models;

import java.io.Serializable;

public class DicomStudy implements Serializable {

	private static final long serialVersionUID = 1L;

}
