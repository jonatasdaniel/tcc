package br.furb.rma.reader;

public interface DicomReaderListener {
	
	void onChange(String status);

}
